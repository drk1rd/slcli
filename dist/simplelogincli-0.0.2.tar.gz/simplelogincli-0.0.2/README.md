# slcli
CLI for Simplelogin by PROTON

- Extremely basic as of now
- API and address stored in plain text, ik ik not secure
- Open to contributions