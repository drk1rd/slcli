import setuptools

setuptools.setup(
    name="simplelogincli",
    version="0.0.2",
    description="A simple CLI for SimpleLogin",
    author="drk1rd",
    url="https://github.com/drk1rd/slcli",
    packages=["simplelogincli"],
)
